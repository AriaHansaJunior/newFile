﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _160423037_Aria_World_Idol
{
    public partial class FormDataKontestan : Form
    {
        FormMenu formMenu;

        public FormDataKontestan()
        {
            InitializeComponent();
        }

        private void FormDataKontestan_Load(object sender, EventArgs e)
        {
            formMenu = (FormMenu)this.Owner;
            foreach (AriaKontestan kontestan in formMenu.listKontestan)
            {
                listBoxData.Items.AddRange(kontestan.DisplayData().Split('\n'));
            }
        }
    }
}

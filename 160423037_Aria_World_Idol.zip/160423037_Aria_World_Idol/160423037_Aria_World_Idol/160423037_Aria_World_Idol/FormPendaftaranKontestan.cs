﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _160423037_Aria_World_Idol
{
    public partial class FormPendaftaranKontestan : Form
    {
        FormMenu formMenu;
        AriaKontestan kontestan;

        public FormPendaftaranKontestan()
        {
            InitializeComponent();
        }

        private void FormPendaftaranKontestan_Load(object sender, EventArgs e)
        {
            formMenu = (FormMenu)this.Owner;
        }

        private void buttonDaftar_Click(object sender, EventArgs e)
        {
            try
            {
                kontestan = new AriaKontestan(textBoxNama.Text, textBoxAsal.Text,
                    int.Parse(textBoxUsia.Text));

                formMenu.listKontestan.Add(kontestan);

                listBoxData.Items.AddRange(kontestan.DisplayData().Split('\n'));

                formMenu.SaveToFile("idol_data.dat");

                textBoxNama.Clear();
                textBoxAsal.Clear();
                textBoxUsia.Clear();

                textBoxNama.Focus();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

﻿namespace _160423037_Aria_World_Idol
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.kontestanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pendaftaranKontestanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataKontestanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.voteMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.babakEliminasiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kontestanToolStripMenuItem,
            this.voteMenuItem,
            this.babakEliminasiToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(533, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // kontestanToolStripMenuItem
            // 
            this.kontestanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pendaftaranKontestanToolStripMenuItem,
            this.dataKontestanToolStripMenuItem});
            this.kontestanToolStripMenuItem.Name = "kontestanToolStripMenuItem";
            this.kontestanToolStripMenuItem.Size = new System.Drawing.Size(72, 22);
            this.kontestanToolStripMenuItem.Text = "Kontestan";
            // 
            // pendaftaranKontestanToolStripMenuItem
            // 
            this.pendaftaranKontestanToolStripMenuItem.Name = "pendaftaranKontestanToolStripMenuItem";
            this.pendaftaranKontestanToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.pendaftaranKontestanToolStripMenuItem.Text = "Pendaftaran Kontestan";
            this.pendaftaranKontestanToolStripMenuItem.Click += new System.EventHandler(this.PendaftaranKontestanToolStripMenuItem_Click);
            // 
            // dataKontestanToolStripMenuItem
            // 
            this.dataKontestanToolStripMenuItem.Name = "dataKontestanToolStripMenuItem";
            this.dataKontestanToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.dataKontestanToolStripMenuItem.Text = "Data Kontestan";
            this.dataKontestanToolStripMenuItem.Click += new System.EventHandler(this.DataKontestanToolStripMenuItem_Click);
            // 
            // voteMenuItem
            // 
            this.voteMenuItem.Name = "voteMenuItem";
            this.voteMenuItem.Size = new System.Drawing.Size(42, 22);
            this.voteMenuItem.Text = "Vote";
            this.voteMenuItem.Click += new System.EventHandler(this.VoteMenuItem_Click);
            // 
            // babakEliminasiToolStripMenuItem
            // 
            this.babakEliminasiToolStripMenuItem.Name = "babakEliminasiToolStripMenuItem";
            this.babakEliminasiToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.babakEliminasiToolStripMenuItem.Text = "Babak Eliminasi";
            this.babakEliminasiToolStripMenuItem.Click += new System.EventHandler(this.BabakEliminasiToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(38, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 94);
            this.Controls.Add(this.menuStrip1);
            this.Name = "FormMenu";
            this.Text = "World Idol";
            this.Load += new System.EventHandler(this.FormMenu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem kontestanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pendaftaranKontestanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataKontestanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem voteMenuItem;
        private System.Windows.Forms.ToolStripMenuItem babakEliminasiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _160423037_Aria_World_Idol
{
    public partial class FormMenu : Form
    {
        public List<AriaKontestan> listKontestan = new List<AriaKontestan> ();

        public FormMenu()
        {
            InitializeComponent();
        }

        private void PendaftaranKontestanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPendaftaranKontestan formMenu = new FormPendaftaranKontestan();
            formMenu.Owner = this;
            formMenu.ShowDialog();
        }

        private void DataKontestanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDataKontestan formMenu = new FormDataKontestan();
            formMenu.Owner = this;
            formMenu.ShowDialog();
        }

        private void VoteMenuItem_Click(object sender, EventArgs e)
        {
            FormVote formMenu = new FormVote();
            formMenu.Owner = this;
            formMenu.ShowDialog();
        }
        private void BabakEliminasiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBabakEliminasi formMenu = new FormBabakEliminasi();
            formMenu.Owner = this;
            formMenu.ShowDialog();
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            LoadFromFile("idol_data.dat");
        }

        public void SaveToFile(string namaFile)
        {
            FileStream file = new FileStream(namaFile, FileMode.Create, FileAccess.Write);
            BinaryFormatter format = new BinaryFormatter();
            format.Serialize(file, listKontestan);
            file.Close();
        }

        public void LoadFromFile(string namaFile)
        {
            if (File.Exists(namaFile))
            {
                FileStream file = new FileStream(namaFile, FileMode.Open, FileAccess.Read);
                BinaryFormatter format = new BinaryFormatter();
                listKontestan = (List<AriaKontestan>)format.Deserialize(file);
                file.Close();
            }
        }
    }
}

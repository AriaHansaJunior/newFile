﻿namespace _160423037_Aria_World_Idol
{
    partial class FormBabakEliminasi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxBatasJumlVoting = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.listBoxData = new System.Windows.Forms.ListBox();
            this.buttonEliminasi = new System.Windows.Forms.Button();
            this.textBoxNamaBabak = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 111);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(241, 18);
            this.label3.TabIndex = 22;
            this.label3.Text = "Daftar Kontestan Tereliminasi :";
            // 
            // textBoxBatasJumlVoting
            // 
            this.textBoxBatasJumlVoting.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxBatasJumlVoting.Location = new System.Drawing.Point(204, 44);
            this.textBoxBatasJumlVoting.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxBatasJumlVoting.Name = "textBoxBatasJumlVoting";
            this.textBoxBatasJumlVoting.Size = new System.Drawing.Size(80, 24);
            this.textBoxBatasJumlVoting.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 44);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(172, 18);
            this.label2.TabIndex = 21;
            this.label2.Text = "Batas Jumlah Voting :";
            // 
            // listBoxData
            // 
            this.listBoxData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxData.FormattingEnabled = true;
            this.listBoxData.Location = new System.Drawing.Point(26, 131);
            this.listBoxData.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxData.Name = "listBoxData";
            this.listBoxData.Size = new System.Drawing.Size(377, 303);
            this.listBoxData.TabIndex = 19;
            // 
            // buttonEliminasi
            // 
            this.buttonEliminasi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEliminasi.Location = new System.Drawing.Point(204, 74);
            this.buttonEliminasi.Margin = new System.Windows.Forms.Padding(2);
            this.buttonEliminasi.Name = "buttonEliminasi";
            this.buttonEliminasi.Size = new System.Drawing.Size(193, 28);
            this.buttonEliminasi.TabIndex = 18;
            this.buttonEliminasi.Text = "ELIMINASI";
            this.buttonEliminasi.UseVisualStyleBackColor = true;
            this.buttonEliminasi.Click += new System.EventHandler(this.buttonEliminasi_Click);
            // 
            // textBoxNamaBabak
            // 
            this.textBoxNamaBabak.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNamaBabak.Location = new System.Drawing.Point(204, 9);
            this.textBoxNamaBabak.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxNamaBabak.Name = "textBoxNamaBabak";
            this.textBoxNamaBabak.Size = new System.Drawing.Size(194, 24);
            this.textBoxNamaBabak.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "Nama Babak Eliminasi :";
            // 
            // FormBabakEliminasi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 443);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxBatasJumlVoting);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBoxData);
            this.Controls.Add(this.buttonEliminasi);
            this.Controls.Add(this.textBoxNamaBabak);
            this.Controls.Add(this.label1);
            this.Name = "FormBabakEliminasi";
            this.Text = "Babak Eliminasi";
            this.Load += new System.EventHandler(this.FormBabakEliminasi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxBatasJumlVoting;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBoxData;
        private System.Windows.Forms.Button buttonEliminasi;
        private System.Windows.Forms.TextBox textBoxNamaBabak;
        private System.Windows.Forms.Label label1;
    }
}
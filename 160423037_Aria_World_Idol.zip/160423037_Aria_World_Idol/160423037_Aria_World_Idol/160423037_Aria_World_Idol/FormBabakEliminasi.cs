﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _160423037_Aria_World_Idol
{
    public partial class FormBabakEliminasi : Form
    {
        FormMenu formMenu;

        public FormBabakEliminasi()
        {
            InitializeComponent();
        }

        private void FormBabakEliminasi_Load(object sender, EventArgs e)
        {
            formMenu = (FormMenu)this.Owner;
        }

        private void buttonEliminasi_Click(object sender, EventArgs e)
        {
            try
            {
                listBoxData.Items.Add("Eliminasi Babak " + textBoxNamaBabak.Text + " telah dilaksanakan");
                listBoxData.Items.Add("");
                listBoxData.Items.Add("Peserta yang tereliminasi adalah: ");
                listBoxData.Items.Add("");

                foreach (AriaKontestan kontestan in formMenu.listKontestan)
                {
                    if (kontestan.JumlahVote < int.Parse(textBoxBatasJumlVoting.Text)
                        && kontestan.BabakEliminasi == "-")
                    {
                        kontestan.Eliminasi(textBoxNamaBabak.Text, int.Parse(textBoxBatasJumlVoting.Text));

                        listBoxData.Items.AddRange(kontestan.DisplayData().Split('\n'));
                    }
                }
                formMenu.SaveToFile("idol_data.dat");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _160423037_Aria_World_Idol
{
    public partial class FormVote : Form
    {
        FormMenu formMenu;

        public FormVote()
        {
            InitializeComponent();
        }

        private void FormVote_Load(object sender, EventArgs e)
        {
            formMenu = (FormMenu)this.Owner;

            comboBoxKontestan.DataSource = formMenu.listKontestan;
            comboBoxKontestan.DisplayMember = "Nama";
        }

        private void buttonVote_Click(object sender, EventArgs e)
        {
            try
            {
                AriaKontestan selected = (AriaKontestan)comboBoxKontestan.SelectedItem;
                selected.Vote();
                formMenu.SaveToFile("idol_data.dat");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

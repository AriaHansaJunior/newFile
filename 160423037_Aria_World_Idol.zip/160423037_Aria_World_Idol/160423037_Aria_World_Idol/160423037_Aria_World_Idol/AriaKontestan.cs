﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _160423037_Aria_World_Idol
{
    [Serializable]
    public class AriaKontestan
    {
        private string nama;
        private string asal;
        private int usia;
        private int jumlahVote;
        private string babakEliminasi;

        #region constructors
        public AriaKontestan(string nama, string asal, int usia)
        {
            this.Nama = nama;
            this.Asal = asal;
            this.Usia = usia;
            this.JumlahVote = 0;
            this.BabakEliminasi = "-";
        }
        #endregion

        #region properties
        public string Nama
        {
            get => nama;
            set
            {
                if (value.Length != 0)
                {
                    nama = value;
                }

                else
                {
                    throw new Exception("Nama peserta tidak boleh kosong");
                }
            }
        }

        public string Asal
        {
            get => asal;
            set
            {
                {
                    if (value.Length != 0)
                    {
                        asal = value;
                    }

                    else
                    {
                        throw new Exception("Asal peserta tidak boleh kosong");
                    }
                }
            }
        }
        public int Usia
        {
            get => usia;
            set
            {
                if (value >= 17 && value <= 30)
                {
                    usia = value;
                }

                else
                {
                    throw new Exception("Usia peserta harus berkisar 17-30 tahun");
                }
            }
        }

        public int JumlahVote
        {
            get => jumlahVote;
            private set
            {
                if (value >= 0)
                {
                    jumlahVote = value;
                }

                else
                {
                    jumlahVote = 0;
                }
            }
        }

        public string BabakEliminasi
        {
            get => babakEliminasi;
            private set => babakEliminasi = value;
        }
        #endregion

        #region methods
        public string DisplayData()
        {
            string data= "Nama Kontestan : " + this.Nama +
                "\nAsal Daerah : " + this.Asal +
                "\nUsia : " + this.Usia +
                "\nJumlah Vote : " + this.JumlahVote +
                "\nTereliminasi di babak : " + babakEliminasi + 
                "\n";

            return data;
        }

        public void Vote()
        {
            if (this.BabakEliminasi == "-")
            {
                this.JumlahVote += 1;
                MessageBox.Show("Voting telah tersimpan, Anda memilih " + this.Nama);
            }
            else
            {
                throw new Exception("Vote gagal. Kontestan telah tereliminasi di babak " 
                    + this.BabakEliminasi);
            }
        }

        public void Eliminasi(string namaBabakEliminasi, int batasMinimumVote)
        {
            if (this.BabakEliminasi == "-")
            {
                if (this.JumlahVote < batasMinimumVote)
                {
                    this.BabakEliminasi = namaBabakEliminasi;
                }
            }
        }
        #endregion

    }
}